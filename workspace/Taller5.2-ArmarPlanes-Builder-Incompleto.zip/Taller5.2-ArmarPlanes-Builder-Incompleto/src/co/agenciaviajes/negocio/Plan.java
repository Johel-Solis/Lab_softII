package co.agenciaviajes.negocio;

import java.util.Arrays;
import java.util.Date;

/**
 *
 * @author Libardo Pantoja, Julio Hurtado, Ricardo Zambrano
 */
public class Plan {

    private Cliente cliente;
    private Date fechaSalida;
    private Date fechaLlegada;
    private String transporte;
    private String alojamiento;
    private String alimentacion;
    private boolean seguroHotelero;
    private boolean impuestoTiqute;
    private String[] tours;
    private int totalAdultos;
    private int totalNinos;
    /**
     * Valor total a pagar
     */
    private int valor;
    
    

    public Plan() {
    }
    
    
    

    /**
     * Incrementa o suma el valor actual del plan
     * @param incremento incremento a sumar
     */
    public void sumarValor(int incremento) {
        this.setValor(this.getValor() + incremento);
    }

    public String toString() {
        return "Cliente: " + getCliente().toString() + " Transporte:" + getTransporte() + " Alojamiento:" + getAlojamiento() + " Alimentación: " + getAlimentacion() + " Impuesto tiquete: " + getImpuestoTiqute() + " Tours: " + Arrays.toString(getTours()) + " Valor $: " + getValor();
    }

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the fechaSalida
     */
    public Date getFechaSalida() {
        return fechaSalida;
    }

    /**
     * @param fechaSalida the fechaSalida to set
     */
    public void setFechaSalida(Date fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    /**
     * @return the fechaLlegada
     */
    public Date getFechaLlegada() {
        return fechaLlegada;
    }

    /**
     * @param fechaLlegada the fechaLlegada to set
     */
    public void setFechaLlegada(Date fechaLlegada) {
        this.fechaLlegada = fechaLlegada;
    }

    /**
     * @return the transporte
     */
    public String getTransporte() {
        return transporte;
    }

    /**
     * @param transporte the transporte to set
     */
    public void setTransporte(String transporte) {
        this.transporte = transporte;
    }

    /**
     * @return the alojamiento
     */
    public String getAlojamiento() {
        return alojamiento;
    }

    /**
     * @param alojamiento the alojamiento to set
     */
    public void setAlojamiento(String alojamiento) {
        this.alojamiento = alojamiento;
    }

    /**
     * @return the alimentacion
     */
    public String getAlimentacion() {
        return alimentacion;
    }

    /**
     * @param alimentacion the alimentacion to set
     */
    public void setAlimentacion(String alimentacion) {
        this.alimentacion = alimentacion;
    }

    /**
     * @return the seguroHotelero
     */
    public boolean getSeguroHotelero() {
        return seguroHotelero;
    }

    /**
     * @param seguroHotelero the seguroHotelero to set
     */
    public void setSeguroHotelero(boolean seguroHotelero) {
        this.seguroHotelero = seguroHotelero;
    }

    /**
     * @return the impuestoTiqute
     */
    public boolean getImpuestoTiqute() {
        return impuestoTiqute;
    }

    /**
     * @param impuestoTiqute the impuestoTiqute to set
     */
    public void setImpuestoTiqute(boolean impuestoTiqute) {
        this.impuestoTiqute = impuestoTiqute;
    }

    /**
     * @return the tours
     */
    public String[] getTours() {
        return tours;
    }

    /**
     * @param tours the tours to set
     */
    public void setTours(String[] tours) {
        this.tours = tours;
    }

    /**
     * @return the totalAdultos
     */
    public int getTotalAdultos() {
        return totalAdultos;
    }

    /**
     * @param totalAdultos the totalAdultos to set
     */
    public void setTotalAdultos(int totalAdultos) {
        this.totalAdultos = totalAdultos;
    }

    /**
     * @return the totalNinos
     */
    public int getTotalNinos() {
        return totalNinos;
    }

    /**
     * @param totalNinos the totalNinos to set
     */
    public void setTotalNinos(int totalNinos) {
        this.totalNinos = totalNinos;
    }

    /**
     * @return the valor
     */
    public int getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(int valor) {
        this.valor = valor;
    }
}
